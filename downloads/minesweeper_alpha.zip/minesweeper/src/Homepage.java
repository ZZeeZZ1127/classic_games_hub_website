import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;

public class Homepage {
  JFrame frame = new JFrame("Minesweeper - Choose Difficulty");
  JRadioButton easyButton = new JRadioButton("Easy (8x8, 10 mines)");
  JRadioButton mediumButton = new JRadioButton("Medium (16x16, 40 mines)", true);
  JRadioButton hardButton = new JRadioButton("Hard (24x24, 99 mines)");
  JButton startButton = new JButton("Start Game");
  JButton easyRecord = new JButton("easy mode record");
  JButton medRecord = new JButton("medium mode record");
  JButton hardRecord = new JButton("hard mode record");
  JPanel buttonPanel = new JPanel();
  RecordManager rm = new RecordManager();

  Homepage() {
    // necessary configurations
    frame.setSize(500, 500);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLayout(new GridLayout(5, 1));
    frame.setLocationRelativeTo(null);

    JLabel label = new JLabel("Select Difficulty", JLabel.CENTER);
    label.setFont(new Font("Arial", Font.BOLD, 18));
    frame.add(label);

    JPanel centerPanel = new JPanel(new GridLayout(3, 3, 10, 10));
    JPanel easyPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
    easyPanel.add(easyButton);
    easyPanel.add(easyRecord);
    JPanel mediumPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
    mediumPanel.add(mediumButton);
    mediumPanel.add(medRecord);
    JPanel hardPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
    hardPanel.add(hardButton);
    hardPanel.add(hardRecord);

    centerPanel.add(easyPanel);
    centerPanel.add(mediumPanel);
    centerPanel.add(hardPanel);

    frame.add(centerPanel, BorderLayout.CENTER);

    ButtonGroup group = new ButtonGroup();
    group.add(easyButton);
    group.add(mediumButton);
    group.add(hardButton);

    JPanel bottomPanel = new JPanel();
    bottomPanel.add(startButton);
    frame.add(bottomPanel, BorderLayout.SOUTH);

    startButton.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        int rows, cols, mines, tileSize;
        if (e.getButton() == MouseEvent.BUTTON1) {
          if (easyButton.isSelected()) {
            rows = cols = 8;
            mines = 10;
            tileSize = 35;
          } else if (mediumButton.isSelected()) {
            rows = cols = 16;
            mines = 40;
            tileSize = 30;
          } else {
            rows = cols = 24;
            mines = 99;
            tileSize = 30;
          }

          frame.dispose();
          new Minesweeper(rows, cols, mines, tileSize);
        }
      }
    });

    easyRecord.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new easyRecords();
      }
    });

    medRecord.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new mediumRecords();
      }
    });

    hardRecord.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new hardRecords();
      }
    });

    frame.setVisible(true);
  }
}
