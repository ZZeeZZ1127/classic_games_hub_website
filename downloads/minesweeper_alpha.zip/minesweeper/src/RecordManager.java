import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class RecordManager {
  private static final String RECORDS_DIR = System.getProperty("user.home") + "/MinesweeperRecords/";
  private static final String EASY_FILE_PATH = RECORDS_DIR + "easyRecords.txt";
  private static final String MEDIUM_FILE_PATH = RECORDS_DIR + "mediumRecords.txt";
  private static final String HARD_FILE_PATH = RECORDS_DIR + "hardRecords.txt";

  // private int easyTime = Integer.MAX_VALUE;
  // private int medTime = Integer.MAX_VALUE;
  // private int hardTime = Integer.MAX_VALUE;

  public RecordManager() {
    File dir = new File(RECORDS_DIR);
    if (!dir.exists()) {
      dir.mkdirs();
    }
  }

  // public void updateRecord(String difficulty, int time) {
  // switch (difficulty) {
  // case "easy":
  // if (time < easyTime)
  // easyTime = time;
  // break;
  // case "medium":
  // if (time < medTime)
  // medTime = time;
  // break;
  // case "hard":
  // if (time < hardTime)
  // hardTime = time;
  // break;
  // }
  // // saveRecords(difficulty, time, );
  // }

  public void saveRecords(String difficulty, int time, String name) {
    if (difficulty.equals("easy")) {
      try (PrintWriter pw = new PrintWriter(new FileWriter(EASY_FILE_PATH, true))) {
        pw.println(time + " by " + name);
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else if (difficulty.equals("medium")) {
      try (PrintWriter pw = new PrintWriter(new FileWriter(MEDIUM_FILE_PATH, true))) {
        pw.println(time + " by " + name);
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else {
      try (PrintWriter pw = new PrintWriter(new FileWriter(HARD_FILE_PATH, true))) {
        pw.println(time + " by " + name);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

  }

}
