import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import javax.swing.plaf.basic.BasicBorders;

public class Minesweeper {
  private class MineTile extends JButton {
    int r;
    int c;

    public MineTile(int r, int c) {
      this.r = r;
      this.c = c;
    }
  }

  int tileSize;
  int numRows;
  int numCols;
  int boardWidth;
  int boardHeight;
  int mineNum;
  int mineFlagNum;
  JButton restartButton = new JButton("restart");
  JButton homePageButton = new JButton("homepage");
  MineTile[][] board;
  Timer timer;
  int elapsedTime = 0;
  long startTime = System.currentTimeMillis();
  long endTime;
  RecordManager rm = new RecordManager();

  JFrame frame = new JFrame("Minesweeper");
  JLabel textLabel = new JLabel();
  JLabel timerLabel = new JLabel("Timer: ");
  JPanel textPanel = new JPanel();
  JPanel boardPanel = new JPanel();
  Random random = new Random();

  ArrayList<MineTile> mineList = new ArrayList<MineTile>();;

  int tilesClicked = -1;
  boolean gameOver = false;

  Minesweeper(int rows, int cols, int mines, int tileSize) {

    numRows = rows;
    numCols = cols;
    mineNum = mines;
    this.tileSize = tileSize;
    mineFlagNum = mines;
    boardWidth = numCols * tileSize + 50;
    boardHeight = numRows * tileSize + 50;

    board = new MineTile[numRows][numCols];

    frame.setSize(boardWidth, boardHeight);
    frame.setLocationRelativeTo(null);
    frame.setResizable(false);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // terminate the program
    frame.setLayout(new BorderLayout());

    textLabel.setFont(new Font("Arial", Font.BOLD, 15));
    textLabel.setHorizontalAlignment(JLabel.CENTER);
    textLabel.setText("Minesweeper 🚩: " + Integer.toString(mineFlagNum));
    textLabel.setOpaque(true);

    textPanel.setLayout(new BorderLayout());
    textPanel.add(textLabel, BorderLayout.CENTER);
    textPanel.add(restartButton, BorderLayout.EAST);
    textPanel.add(homePageButton, BorderLayout.WEST);
    textPanel.add(timerLabel, BorderLayout.NORTH);
    frame.add(textPanel, BorderLayout.NORTH);

    restartButton.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new Minesweeper(numRows, numCols, mineNum, tileSize);
      }
    });

    homePageButton.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new Homepage();
      }
    });

    // timer
    timer = new Timer(1000, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        elapsedTime++;
        timerLabel.setText("Timer: " + elapsedTime);
      }
    });

    boardPanel.setLayout(new GridLayout(numRows, numCols));
    // boardPanel.setBackground(Color.green);
    frame.add(boardPanel);

    for (int r = 0; r < numRows; r++) {
      for (int c = 0; c < numCols; c++) {
        MineTile tile = new MineTile(r, c);
        board[r][c] = tile;

        tile.setFocusable(false); // prevent keyboard focus
        tile.setMargin(new Insets(0, 0, 0, 0)); // ?
        tile.setFont(new Font("Arial Unicode MS", Font.PLAIN, 25));
        tile.setBackground(Color.GREEN);
        tile.setBorder(BorderFactory.createLineBorder(Color.black));
        tile.setContentAreaFilled(true);
        tile.setOpaque(true);
        tile.addMouseListener(new MouseAdapter() { // ?
          @Override // ?
          public void mousePressed(MouseEvent e) {
            if (gameOver) {
              return;
            }
            MineTile tile = (MineTile) e.getSource(); // ?

            // left click
            if (e.getButton() == MouseEvent.BUTTON1) {
              if (tile.getText() == "") {
                if (mineList.contains(tile)) {
                  revealMines();
                } else {
                  checkMine(tile.r, tile.c);
                }
              } // if it is a number, click on it and reveal all the available blocks around if
                // mines are marked correctly
              else if (!tile.getText().equals("") && !tile.getText().equals("🚩")) {
                if (isMatchedTimes(tile.r, tile.c) == countTotalMines(tile.r, tile.c)
                    && flagCount(tile.r, tile.c) == countTotalMines(tile.r, tile.c)) {
                  revealSurroundings(tile.r, tile.c);
                } else if (flagCount(tile.r, tile.c) == countTotalMines(tile.r, tile.c)
                    && isMatchedTimes(tile.r, tile.c) < countTotalMines(tile.r, tile.c)) {
                  revealMines();
                }
              }

            }
            // Right click
            else if (e.getButton() == MouseEvent.BUTTON2 || e.getButton() == MouseEvent.BUTTON3 && tile.isEnabled()) {
              if (tile.getText().equals("")) {
                tile.setText("🚩");
                mineFlagNum--;
                updateFlagCountLabel();
              } else if (tile.getText().equals("🚩")) {
                tile.setText("");
                mineFlagNum++;
                updateFlagCountLabel();
              }
            }
          }
        });
        boardPanel.add(tile);

      }
    }
    frame.setVisible(true);// make sure this is the last line in constructor

  }

  void setMines(int safeRow, int safeCol) {

    int n = mineNum;

    while (n > 0) {
      int row = random.nextInt(numRows);
      int col = random.nextInt(numCols);
      // avoid mines in the 3x3 area centered at the first click point
      if (!mineList.contains(board[row][col]) && !(row >= safeRow - 1 && row <= safeRow + 1
          && col >= safeCol - 1 && col <= safeCol + 1)) {
        mineList.add(board[row][col]);
        n--;
      }
    }
    // int b = (int) (mineNum * 0.1);
    // int n = mineNum - b;

    // while (b > 0) {
    // int row = random.nextInt(numRows - 2) + 1;
    // int col = random.nextInt(numCols - 2) + 1;
    // if (!mineList.contains(board[row][0])) {
    // mineList.add(board[row][0]);
    // b--;
    // } else if (!mineList.contains(board[row][numCols - 1])) {
    // mineList.add(board[row][numCols - 1]);
    // b--;
    // } else if (!mineList.contains(board[0][col])) {
    // mineList.add(board[0][col]);
    // b--;
    // } else if (!mineList.contains(board[numRows - 1][col])) {
    // mineList.add(board[numRows - 1][col]);
    // b--;
    // }
    // }

    // while (n > 0) {
    // int row = random.nextInt(numRows - 2) + 1;
    // int col = random.nextInt(numCols - 2) + 1;
    // if (!mineList.contains(board[row][col])) {
    // mineList.add(board[row][col]);
    // n--;
    // }
    // }
  }

  void revealMines() {
    for (int i = 0; i < mineList.size(); i++) {
      MineTile tile = mineList.get(i);
      tile.setText("💣");
    }

    gameOver = true;
    textLabel.setText("Game Over!");
    if (timer != null) {
      timer.stop();
    }
  }

  // click and reveal the non-mine blocks
  void checkMine(int r, int c) {
    if (r < 0 || r >= numRows || c < 0 || c >= numCols) {
      return;
    }

    MineTile tile = board[r][c];
    if (tile.getBackground().equals(Color.LIGHT_GRAY)) {
      return;
    }
    tile.setBackground(Color.LIGHT_GRAY);
    tilesClicked++;

    // for the first click
    if (tilesClicked == 0) {
      tile.setText(""); // first revealed mine is always blank
      tile.setBackground(Color.LIGHT_GRAY);
      setMines(r, c); // set mines after the first click
      timer.start();
      tilesClicked++; // enter the next phase of checking mines after the first click
    }

    // help to reveal a large area of tiles even for the first click
    if (tilesClicked > 0) {
      if (countTotalMines(r, c) > 0) {
        tile.setText(Integer.toString(countTotalMines(r, c)));
      } else {
        tile.setText("");
        checkMine(r - 1, c - 1);
        checkMine(r - 1, c);
        checkMine(r - 1, c + 1);
        checkMine(r, c - 1);
        checkMine(r, c + 1);
        checkMine(r + 1, c - 1);
        checkMine(r + 1, c);
        checkMine(r + 1, c + 1);
      }
    }

    if (tilesClicked == numRows * numCols - mineList.size()) {
      gameOver = true;
      textLabel.setText("Congratulation! Mines Cleared!");
      if (timer != null) {
        timer.stop();
        endTime = System.currentTimeMillis();
        int elapsedSeconds = (int) ((endTime - startTime) / 1000);
        String name = JOptionPane.showInputDialog(null, "please type in your name for your time record: ");

        // different records.txt for different modes
        if (mineNum == 10) {
          rm.saveRecords("easy", elapsedSeconds, name);
        } else if (mineNum == 40) {
          rm.saveRecords("medium", elapsedSeconds, name);
        } else {
          rm.saveRecords("hard", elapsedSeconds, name);
        }
      }

    }
  }
  // mine counting

  int countMine(int r, int c) {
    if (r < 0 || r >= numRows || c < 0 || c >= numCols) {
      return 0;
    }
    if (mineList.contains(board[r][c])) {
      return 1;
    }
    return 0;
  }

  int countTotalMines(int r, int c) {
    int minesFound = 0;

    // top 3
    minesFound += countMine(r - 1, c - 1);
    minesFound += countMine(r - 1, c);
    minesFound += countMine(r - 1, c + 1);

    // left and right
    minesFound += countMine(r, c - 1);
    minesFound += countMine(r, c + 1);

    // bottom 3
    minesFound += countMine(r + 1, c - 1);
    minesFound += countMine(r + 1, c);
    minesFound += countMine(r + 1, c + 1);

    return minesFound;
  }

  void updateFlagCountLabel() {
    textLabel.setText("Minesweeper  🚩: " + Integer.toString(mineFlagNum));
  }

  boolean isMatched(int r, int c) {
    if (board[r][c].getText().equals("🚩") && mineList.contains(board[r][c])) {
      return true;
    }
    return false;
  }

  // matched times of flags and mines
  int isMatchedTimes(int r, int c) {
    int count = 0;
    if (r > 0 && c > 0 && isMatched(r - 1, c - 1)) {
      count++;
    }
    if (r > 0 && isMatched(r - 1, c)) {
      count++;
    }
    if (r > 0 && c < numCols - 1 && isMatched(r - 1, c + 1)) {
      count++;
    }
    if (c > 0 && isMatched(r, c - 1)) {
      count++;
    }
    if (c < numCols - 1 && isMatched(r, c + 1)) {
      count++;
    }
    if (r < numRows - 1 && c > 0 && isMatched(r + 1, c - 1)) {
      count++;
    }
    if (r < numRows - 1 && isMatched(r + 1, c)) {
      count++;
    }
    if (r < numRows - 1 && c < numCols - 1 && isMatched(r + 1, c + 1)) {
      count++;
    }
    return count;
  }

  int flagCount(int r, int c) {
    int count = 0;
    if (r > 0 && c > 0 && board[r - 1][c - 1].getText().equals("🚩")) {
      count++;
    }
    if (r > 0 && board[r - 1][c].getText().equals("🚩")) {
      count++;
    }
    if (r > 0 && c < numCols - 1 && board[r - 1][c + 1].getText().equals("🚩")) {
      count++;
    }
    if (c > 0 && board[r][c - 1].getText().equals("🚩")) {
      count++;
    }
    if (c < numCols - 1 && board[r][c + 1].getText().equals("🚩")) {
      count++;
    }
    if (r < numRows - 1 && c > 0 && board[r + 1][c - 1].getText().equals("🚩")) {
      count++;
    }
    if (r < numRows - 1 && board[r + 1][c].getText().equals("🚩")) {
      count++;
    }
    if (r < numRows - 1 && c < numCols - 1 && board[r + 1][c + 1].getText().equals("🚩")) {
      count++;
    }
    return count;
  }

  // reveal the surroundings, only if every flag match with every mine, and every
  // mine is marked
  void revealSurroundings(int r, int c) {
    if (r > 0 && c > 0 && !board[r - 1][c - 1].getText().equals("🚩")) {
      checkMine(r - 1, c - 1);
    }
    if (r > 0 && !board[r - 1][c].getText().equals("🚩")) {
      checkMine(r - 1, c);
    }
    if (r > 0 && c < numCols - 1 && !board[r - 1][c + 1].getText().equals("🚩")) {
      checkMine(r - 1, c + 1);
    }
    if (c > 0 && !board[r][c - 1].getText().equals("🚩")) {
      checkMine(r, c - 1);
    }
    if (c < numCols - 1 && !board[r][c + 1].getText().equals("🚩")) {
      checkMine(r, c + 1);
    }
    if (r < numRows - 1 && c > 0 && !board[r + 1][c - 1].getText().equals("🚩")) {
      checkMine(r + 1, c - 1);
    }
    if (r < numRows - 1 && !board[r + 1][c].getText().equals("🚩")) {
      checkMine(r + 1, c);
    }
    if (r < numRows - 1 && c < numCols - 1 && !board[r + 1][c + 1].getText().equals("🚩")) {
      checkMine(r + 1, c + 1);
    }
  }
}
