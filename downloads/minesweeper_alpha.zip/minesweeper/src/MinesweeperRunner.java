import javax.swing.text.html.MinimalHTMLWriter;

public class MinesweeperRunner {
    public static void main(String[] args) {
        new Homepage();
    }
}
