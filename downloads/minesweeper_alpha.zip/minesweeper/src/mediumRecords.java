import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.*;

public class mediumRecords {
  JFrame frame = new JFrame("medium mode records");
  private static final String DIR = System.getProperty("user.home") + "/MinesweeperRecords/";
  private static final String MEDIUM_PATH = DIR + "mediumRecords.txt";

  String name;
  int time;

  mediumRecords() {
    displayRanking(MEDIUM_PATH);
  }

  mediumRecords(String name, int time) {
    this.name = name;
    this.time = time;
  }

  public List<mediumRecords> readRecordsFromFile(String fileName) {
    List<mediumRecords> records = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = reader.readLine()) != null) {
        String[] parts = line.split(" by ");
        if (parts.length == 2) {
          String name = parts[1];
          int time = Integer.parseInt(parts[0].trim());
          records.add(new mediumRecords(name, time));
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    records.sort(Comparator.comparingInt(r -> r.time));
    return records;
  }

  public void showSortedRecords(List<mediumRecords> records) {
    JFrame frame = new JFrame("Medium Mode Rankings");
    JButton homePageButton = new JButton("homepage");

    JTextArea textArea = new JTextArea();
    textArea.setEditable(false);

    StringBuilder sb = new StringBuilder();
    sb.append("ranking\ttime (in seconds)\tplayer\n");
    for (int i = 0; i < records.size(); i++) {
      sb.append((i + 1)).append("\t").append(records.get(i).time).append("\t\t").append(records.get(i).name)
          .append("\n");
    }

    homePageButton.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        frame.dispose();
        new Homepage();
      }
    });

    textArea.setText(sb.toString());
    frame.add(new JScrollPane(textArea));
    frame.setSize(500, 400);
    frame.setLocationRelativeTo(null);
    frame.add(homePageButton, BorderLayout.SOUTH);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);

  }

  public void displayRanking(String fileName) {
    List<mediumRecords> records = readRecordsFromFile(fileName);
    showSortedRecords(records);
  }

}
