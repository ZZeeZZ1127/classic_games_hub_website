
public class Main{
  public static void main(String[] args){
    new newGUI(1);

    if (Asky.getWin() == true){
      newGUI.setCurrent(true);
      Asky.setWin(false);
      newGUI.setI(1);
      Asky.setDisplay("");
      Asky.setGuesses(null);
      Asky.setNumGuesses(0);
    }
  }  

}