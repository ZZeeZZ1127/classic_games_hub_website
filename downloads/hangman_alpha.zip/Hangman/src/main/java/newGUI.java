import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.Image;




public class newGUI extends JFrame{

  JButton enter_button;
  static JLabel label = new JLabel();
  private static boolean current = true;
  private static int i;
  static JFrame frame = new JFrame();
  static JTextField textfield = new JTextField();
  
  
  public newGUI(int i){
    
    setI(i);
    

    textfield.setPreferredSize(new Dimension(250,40));
    textfield.setBounds(80, 400, 225, 25);
    textfield.setBackground(Color.PINK);
    textfield.setVisible(true);
    
    enter_button = new JButton();
    enter_button.setBounds(350,400,100,25);
    enter_button.setText("ENTER");
    enter_button.setFocusable(false);
    enter_button.setHorizontalTextPosition(JButton.CENTER);
    enter_button.setVerticalTextPosition(JButton.BOTTOM);
    enter_button.setFont(new Font("Helvetica", Font.BOLD, 20));
    enter_button.setForeground(Color.orange);
    enter_button.setBackground(Color.lightGray);
    enter_button.setBorder(BorderFactory.createEtchedBorder());

    
    ImageIcon icon_image = new ImageIcon("src/main/java/hangman" + i + ".png");
    int newWidth = 200; // Desired width
    int newHeight = 200; // Desired height
    Image scaledImage = icon_image.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
    Border border = BorderFactory.createLineBorder(Color.black, 3);


    
    if (current){
      label.setText("Enter a secret word in all lowercase!");
    }
    else if (!current && Asky.getNumGuesses() == 0){
      label.setText("Enter a one-letter guess! " + Asky.getDisplay());
    }

    
    
    label.setIcon(new ImageIcon(scaledImage));
    label.setHorizontalTextPosition(JLabel.CENTER);
    label.setVerticalTextPosition(JLabel.TOP);
    label.setForeground(Color.black);
    label.setFont(new Font("Helvetica", Font.PLAIN, 20));
    
    label.setIconTextGap(10); //double check this line later; trial and error
    label.setBackground(new Color(100, 232, 170));
    label.setOpaque(true);
    label.setBorder(border);
    label.setVerticalAlignment(JLabel.CENTER);
    label.setHorizontalAlignment(JLabel.CENTER);
    label.setBounds(0, 0, 500, 500);
    JPanel panel = new JPanel();
    panel.setBounds(0, 0, 500, 500);
    panel.add(label);

   

    
    
    frame.setTitle("Hangman"); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    frame.setSize(500, 500);
    frame.setLayout(null);
    frame.add(enter_button);
    frame.add(textfield);
    frame.add(label);
    frame.getContentPane().setBackground(Color.white); 
    frame.setVisible(true);
    frame.add(panel);
    
    enter_button.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e){

          if (e.getSource() == enter_button){
            if (current){
              Asky.setSec(textfield.getText());
              current = false;
              Asky.initializeDisplay();
              textfield.setText("");

              newGUI gui1 = new newGUI(1);
            }
            else{

              Asky.setTexts(Asky.tryit(textfield.getText()));

              label.setText(Asky.returnTexts() + " " + Asky.getDisplay());
              label.setVisible(true);
              frame.add(label);
//something sus here
              if (Asky.returnTexts().equals("Wrong. Try another letter!")){
                setI(getI() + 1);

                ImageIcon icon_image = new ImageIcon("src/main/java/hangman" + getI() + ".png");
                int newWidth = 200; // Desired width
                int newHeight = 200; // Desired height
                Image scaledImage = icon_image.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
                label.setIcon(new ImageIcon(scaledImage));
                textfield.setText("");

                label.setVisible(true);
                frame.add(label);
                newGUI gui2 = new newGUI(getI());
              }
              else if (Asky.returnTexts().equals("That was right! Guess again!") || Asky.returnTexts().equals("You already guessed that!")){
                textfield.setText("");
                label.setVisible(true);
                frame.add(label);
                newGUI gui3 = new newGUI(getI());
              }
              else if (Asky.returnTexts().equals("You got it!")){

                textfield.setText("");
                //getsec not appearing
                label.setText("You got it! Secret word: " + Asky.getSec());
                label.setVisible(true);
                frame.add(label);
                Asky.setCount(0);
                

                newGUI gui4 = new newGUI(getI());
                //add # of guesses taken
              }
              
              else{
                label.setVisible(true);
                frame.add(label);
                label.setText("RIP! The word was " + Asky.getSec());
                newGUI gui5 = new newGUI(getI());
                Asky.setCount(0);
              }




            }
          }

        }
      });
    }
    
  public static int getI(){
    return i;
  }
  public static boolean getCurrent(){
    return current;
  }

  public static void setCurrent(boolean current2){
    current = current2;
  }
  
  public static void setI(int i2){
    i = i2;
  }
}
  
