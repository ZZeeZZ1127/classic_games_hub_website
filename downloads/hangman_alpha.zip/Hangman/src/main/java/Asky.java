import java.util.ArrayList;

public class Asky {
  private static int count = 0;
  private static String sec;
  private static int num_guesses = 0;
  private static ArrayList<String> guesses = new ArrayList<String>();
  private static boolean win = false;
  private static String display = "";
  private static ArrayList<String> wrongguesses = new ArrayList<String>();
  private static String texts;

  public static void initializeDisplay() {
    for (int i = 0; i < sec.length(); i++) {
      display += "-";
    }
    // * is also fine
  }

  public static void setSec(String sec2) {
    sec = sec2;
  }

  public static void setDisplay(String display2) {
    display = display2;
  }

  public static void updateDisplay(String guess) {
    if (guess.length() > 1) {
      if (guess.equals(sec)) {
        display = sec;
      }

      else if (sec.indexOf(guess) != -1) {
        display = display.substring(0, sec.indexOf(guess)) + guess
            + display.substring(sec.indexOf(guess) + guess.length());
      }
    }

    else if (guess.length() == 1) {
      for (int i = 0; i < sec.length(); i++) {
        if (sec.charAt(i) == guess.charAt(0)) {
          display = display.substring(0, i) + guess + display.substring(i + 1);
        }
      }
    }
  }

  public static String tryit(String guess) {
    num_guesses++;
    updateDisplay(guess);
    boolean valid = false;
    // precondition: guess is a single letter
    for (int i = 0; i < sec.length(); i++) {
      if (sec.charAt(i) == guess.charAt(0)) {
        valid = true;
      }
    }

    // secret word is test
    // guess is t
    // display is t__t

    if (Asky.getSec().equals(guess) || getDisplay().equals(Asky.getSec())) {
      win = true;
      guesses.add(guess);
      return "You got it!";
    }
    if (wrongguesses.size() >= 7) {
      return "You lose! The word was " + sec;
    }

    if (valid && guesses.indexOf(guess) == -1) {
      guesses.add(guess);
      return "That was right! Guess again!";
    } else if (guesses.indexOf(guess) == -1) {
      count++;
      wrongguesses.add(guess);
      guesses.add(guess);
      return "Wrong. Try another letter!";
    } else {
      return "You already guessed that!";
    }
  }

  public static String returnTexts() {
    return texts;
  }

  public static void setTexts(String texts2) {
    texts = texts2;
  }

  public static void setGuesses(ArrayList<String> guesses2) {
    guesses = guesses2;
  }

  public static int getNumGuesses() {
    return num_guesses;
  }

  public static void setNumGuesses(int num_guesses2) {
    num_guesses = num_guesses2;
  }

  public static String getDisplay() {
    return display;
  }

  public static String getSec() {
    return sec;
  }

  public static int getCount() {
    return count;
  }

  public static void setCount(int count2) {
    count = count2;
  }

  public static boolean getWin() {
    return win;
  }

  public static void setWin(boolean win2) {
    win = win2;
  }

  public static String wordbank() {
    return wrongguesses.toString();
  }
}