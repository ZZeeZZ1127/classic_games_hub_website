
import java.net.NetworkInterface;
import java.util.Scanner;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.border.Border;

public class GUI extends JFrame{
  public static JFrame frame;
  public static JPanel panel;
  public static JLabel title;
  public static JLabel info;
  public static JTextField userInput;
  public static JLabel[] labels;
  public static JButton replayButton;


  public static void main(String[] args) {
    frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setTitle("Wordle");
    frame.setSize(440, 500);
    frame.setLocationRelativeTo(null);

    panel = new JPanel();
    panel.setLayout(null);
    frame.add(panel);

    panel.setLayout(null);
    title = new JLabel("Wordle: ");
    title.setFont(new Font("Arial", Font.BOLD, 28));
    title.setBounds(160, 20, 200, 30);
    panel.add(title);

    panel.setLayout(null);
    info = new JLabel("Type a five letter word");
    info.setFont(new Font("Arial", Font.PLAIN, 18));
    info.setBounds(120, 60, 250, 25);
    panel.add(info);

    userInput = new JTextField(); 
    userInput.setBounds(120, 95, 160, 30);
    panel.add(userInput);

    replayButton = new JButton("Replay");
    replayButton.setBounds(170, 320, 100, 30);
    replayButton.setVisible(false);
    replayButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        for (JLabel label : GUI.labels)
        {
          label.setText("");
        }
        info.setText("Type a five letter word");
        info.setForeground(Color.BLACK);
        userInput.setText("");
        userInput.setVisible(true);
        userInput.setEnabled(true);
        userInput.setBounds(120, 95, 160, 35);
        replayButton.setVisible(false);

        Wordle newGame = new Wordle();
        newGame.startGame();
      }
    });
    panel.add(replayButton);

    labels = new JLabel[6];
    for (int i = 0; i < 6; i++) {
      labels[i] = new JLabel();
      labels[i].setFont(new Font("Arial", Font.PLAIN, 20));
      labels[i].setBounds(180, 95 + i * 35, 160, 30);
      panel.add(labels[i]);
    }
    Wordle game = new Wordle();
    game.startGame();

    userInput.addActionListener(game);

    frame.setVisible(true);


  }


}