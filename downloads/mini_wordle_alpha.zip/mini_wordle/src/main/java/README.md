# Java Wordle

This is a Wordle-style word guessing game built in Java using Swing for the graphical user interface. Players have 6 attempts to guess a randomly chosen 5-letter word. Feedback is given using colored letters that indicate correct letters in the correct or incorrect positions.

## Features

- Input-based word guessing with a movable text field like the NYT Wordle
- Color-coded feedback using HTML in `JLabel`:
  - Green: Correct letter in the correct position
  - Yellow: Correct letter in the wrong position
  - Black: Incorrect letter
- Input validation against a preset word bank
- Replay button after the game ends

## How to Run

### Requirements
- Java Development Kit (JDK 8 or later)
- Any Java-compatible IDE or terminal

### Steps
1. Clone or download the project folder.
2. Make sure the following files are present:
   - `GUI.java`
   - `Wordle.java`
   - `Wordbank.java`
3. Compile all Java files:
   ```bash
   javac *.java
