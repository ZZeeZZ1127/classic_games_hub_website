import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JLabel;

public class Wordle implements ActionListener {

  public String guess;
  public static char[] input;
  public static char[] answerChars;
  public static boolean done;
  public static String answerChosen;
  public static int tries;
  public static int[] colors;
  public static JLabel[] labels;

  public void startGame() {
    answerChosen = Wordbank.getRandomWord();
    answerChars = answerChosen.toCharArray();
    input = new char[5];
    tries = 0;

  }

  public void endGame() {
    GUI.userInput.setEnabled(false);
    GUI.userInput.setVisible(false);

    if (!done) {
      GUI.info.setText("The answer is " + answerChosen);
      GUI.info.setForeground(Color.RED);
    }

    else {
      GUI.info.setText("You Found The Answer!");
      GUI.info.setForeground(Color.GREEN);
    }

    GUI.replayButton.setVisible(true);

  }

  @Override
  public void actionPerformed(ActionEvent e) {
    enterWord();
  }

  public void enterWord() {
    GUI.info.setText("Type a five letter word");
    GUI.info.setForeground(Color.BLACK);
    if (Wordbank.isValid(GUI.userInput.getText()))
      buttonPressed();
    else {
      GUI.info.setText("Invalid Word");
      GUI.info.setForeground(Color.RED);
    }
  }

  public void buttonPressed() {
    guess = GUI.userInput.getText();

    if (!Wordbank.isValid(guess)) {
      GUI.info.setText("Invalid word!");
      GUI.info.setForeground(Color.RED);
      return;
    }

    String[] lettercols = playWordle(guess);
    GUI.userInput.setBounds(120, 95 + (tries * 35), 160, 30);

    GUI.userInput.setText(""); 
    done = true;
    for (int i = 0; i < lettercols.length; i++) {
      if (!lettercols[i].equalsIgnoreCase("green")) {
        done = false;
        break;
      }
    }
    
    StringBuilder html = new StringBuilder("<html>");
    for (int i = 0; i < 5; i++) {
      html.append("<font color='").append(lettercols[i]).append("'>")
          .append(guess.charAt(i))
          .append("</font>");
    }
    html.append("</html>");
    setNextLabel(html.toString());

    if (done || tries >= 6) {
      endGame();
    }
  }

  public void setNextLabel(String a) {
    GUI.labels[tries - 1].setText(a);
  }

  public String[] playWordle(String a) {
    done = false;
    tries++;
    String x = a.toLowerCase();
    if (!Wordbank.isValid(x)) {
      System.out.print("invalid");
    } else {
      for (int i = 0; i < 5; i++) {
        input[i] = x.charAt(i);
      }
    }

    for (int i = 0; i < 5; i++) {
      answerChars[i] = answerChosen.charAt(i);
    }
    return color(input, answerChars);
  }

  public String[] color(char[] inp, char[] ans) {
    char[] temp = ans;
    String[] col = new String[5];
    String a = "-";
    for (int i = 0; i < 5; i++) {
      col[i] = "black";
    }
    for (int i = 0; i < 5; i++) {
      if (inp[i] == ans[i]) {
        temp[i] = a.charAt(0);
        col[i] = "green";
      }
    }

    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (inp[i] == temp[j] && !col[i].equals("green")) {
          col[i] = "orange";
          temp[j] = a.charAt(0);
        }
      }
    }
    return col;
  }

}
