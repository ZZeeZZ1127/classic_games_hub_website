package Finalproject.code;

public class Board {

    private int[][] board;
    public Board(){
        this(3);
    }
    public Board(int s){
        board = new int[s][s];
    }
    public boolean move(int r, int c, int player){
        if (board[r][c]==0){
            board[r][c] = player;
            return true;
        }
        else return false;
    }

    public boolean checkWin(int r, int c, int player) {
        int boardSize = board.length;
        int winLength = 5;
        int scanLength = 9;
        if(board.length<winLength){
            winLength=3;
            scanLength =3;
        }
        // Define the four directions: (dr, dc)
        int[][] directions = {
            {0, 1},   // horizontal
            {1, 0},   // vertical
            {1, 1},   // diagonal \
            {1, -1}   // diagonal /
        };

        for (int[] dir : directions) {
            int dr = dir[0], dc = dir[1];
            // Step back up to 9 steps to find the top/left-most start
            int startR = r - dr * (scanLength - 1);
            int startC = c - dc * (scanLength - 1);
            for (int i = 0; i < scanLength; i++) {
                int rr = startR + dr * i;
                int cc = startC + dc * i;
                int count = 0;
                for (int j = 0; j < winLength; j++) {
                    int checkR = rr + dr * j;
                    int checkC = cc + dc * j;
                    if (checkR < 0 || checkR >= boardSize || checkC < 0 || checkC >= boardSize) {
                        break; // out of bounds
                    }
                    if (board[checkR][checkC] == player) {
                        count++;
                    } else {
                        break;
                    }
                }
                if (count == winLength) {
                    return true;
                }
            }
        }
        return false;
    }
}    