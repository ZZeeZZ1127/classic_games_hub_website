package Finalproject.code;


import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;



public class GameFrame extends JFrame implements ActionListener {

    Board arrayBoard;
    private int stepCount=0;
    private int startplayer = 1;
    private JButton[][] cells;
    private JFrame Game;
    private int size;
    

    ImageIcon circle = new ImageIcon("Finalproject/resources/circle.png");
    ImageIcon cross = new ImageIcon("Finalproject/resources/cross.png");

    public GameFrame(int s, int ws){
        this.size=s;

        Game = new JFrame();
        Game.setTitle("Tic-tac-toe");
        Game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Game.setResizable(false);
        Game.setSize(ws,ws);
        Game.setLocationRelativeTo(null);

        arrayBoard = new Board(s);
        cells = new JButton[size][size];
        JPanel board = new JPanel(new GridLayout(size, size));

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                JButton btn = new JButton();
                cells[i][j] = btn; 
                int row = i; // must be final or effectively final for lambda
                int col = j;

                setButtonAction(btn, row, col);

                board.add(btn);
                SwingUtilities.invokeLater(() -> {
                    btn.setFont(new Font("Arial", Font.PLAIN, (int)(btn.getHeight() * 0.7)));
                });
            }
        }


        //ready frame
        Game.add(board);
        Game.setVisible(true);
    } 


    private void setButtonAction(JButton btn, int row, int col) {
        btn.addActionListener(e -> {
            System.out.println("Button clicked at: " + row + ", " + col);
            boolean x = arrayBoard.move(row, col, startplayer);
            if (x) {
                move(row, col, startplayer);
                startplayer = 3 - startplayer;
                stepCount++;
            }
        });
    }

    public void move(int r, int c, int player){
        if(player ==1) cells[r][c].setText("O");
        else if (player == 2) cells[r][c].setText("X");
        this.end(r, c, player);
    }

    public void end(int r, int c, int player){
        if (arrayBoard.checkWin(r, c, player)){
            if (stepCount<size*size-1){
                if (player == 1) JOptionPane.showMessageDialog(Game, "Player 1 win!", "title", JOptionPane.PLAIN_MESSAGE);
                else JOptionPane.showMessageDialog(Game, "Player 2 win!", "title", JOptionPane.QUESTION_MESSAGE);
            }
            else if (stepCount == size*size-1) JOptionPane.showMessageDialog(Game, "Tie!", "title", JOptionPane.QUESTION_MESSAGE);
            Game.dispose();
            StarterFrame start = new StarterFrame();

            
        } 
        System.out.println(stepCount);
        System.out.println(size*size-1);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }


}
