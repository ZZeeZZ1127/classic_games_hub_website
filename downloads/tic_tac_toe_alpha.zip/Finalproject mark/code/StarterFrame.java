package Finalproject.code;


import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.*;

public class StarterFrame extends JFrame implements ActionListener  {
    
    private CardLayout cardLayout;
    private JPanel starterPanel; 
    JFrame starter;
    JComboBox sizeBox;
    JComboBox modeBox;
    JComboBox levelBox;

    public StarterFrame(){
        //create StartFrame
        starter = new JFrame();
        starter.setTitle("Tic-tac-toe");
        starter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        starter.setResizable(false);
        starter.setSize(420,420);
        starter.setLocationRelativeTo(null);
        //starter.pack(); -resize the frame to fit the label


        // CardLayout to switch between screens
        cardLayout = new CardLayout();
        starterPanel = new JPanel(cardLayout);

        JPanel menuPanel = createMenuPanel();
        JPanel settingsPanel = createSettingsPanel();

        starterPanel.add(menuPanel, "Menu");
        starterPanel.add(settingsPanel, "Settings");


        starter.add(starterPanel);
        starter.setVisible(true);
    
    }
    
    
    private JPanel createMenuPanel() {
        //create lable
        
        JPanel panel = new JPanel(null);
        
        ImageIcon startIcon = new ImageIcon("Finalproject/resources/startIcon.jpeg");
        
        JLabel label = new JLabel();
        label.setText("Tic-Tac-Toe");
        label.setIcon(startIcon);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(new Color(100, 100, 100));
        label.setFont(new Font("MV Boli", Font.PLAIN, 35));
        Border startborder = BorderFactory.createLineBorder(Color.RED,4);
        label.setBorder(startborder);
        label.setBounds(0,0,420,420); 
        // image load checker
        if (startIcon.getIconWidth() == -1 ) {
            System.out.println("Image not found or failed to load.");           
        } 
        else {
            System.out.println("Image loaded successfully!");
        }
        System.out.println(System.getProperty("user.dir"));
        panel.add(label);
        
        
        //Create startbutton
        JButton startB = new JButton();
        startB.setBounds(270, 140, 100,40);
        startB.setText("Start");
        startB.setHorizontalTextPosition(JButton.CENTER);
        startB.setVerticalTextPosition(JButton.CENTER);
        startB.setForeground(Color.ORANGE);
        startB.setBackground(Color.GRAY);
        startB.setOpaque(true);
        startB.setBorder(BorderFactory.createEtchedBorder());
        startB.addActionListener(e -> {
            int size;
            int Windowsize;
            if (sizeBox.getSelectedIndex()==0) {
                size = 3;
                Windowsize = 300;
            }
            else if (sizeBox.getSelectedIndex()==1){
                size =5;
                Windowsize = 500;
            }
            else {
                size = 21;
                Windowsize = 700;
            }

            GameFrame game = new GameFrame(size, Windowsize);
            starter.dispose();
        });
        panel.add(startB);

        //Create settingbutton
        JButton settingB = new JButton();
        settingB.setBounds(270, 220, 100, 40);
        settingB.setText("Setting");
        settingB.setHorizontalTextPosition(JButton.CENTER);
        settingB.setVerticalTextPosition(JButton.CENTER);
        settingB.setForeground(Color.ORANGE);
        settingB.setBackground(Color.WHITE);
        settingB.setOpaque(true);
        settingB.setBorder(BorderFactory.createEtchedBorder());
        settingB.addActionListener(e -> {
            cardLayout.show(starterPanel, "Settings"); // switch to settings
            System.out.println("Go to setting page");
        });
        panel.add(settingB);

        //return
        return panel;
    }

    private JPanel createSettingsPanel() {
        JPanel panel = new JPanel(null);
        JPanel subp = new JPanel();
        subp.setBounds(100, 120, 200, 200);
        subp.setLayout(new BoxLayout(subp, BoxLayout.Y_AXIS));

        // combo boxes
        String[] sizeStrings = {"3*3","5*5(5 in a row)","21*21(5 in a row)"};
        //String[] modeStrings = {"Single player (with bot)", "Two player"};
        //String[] levelStrings = {"Easy", "Moderate", "Hard"};
        sizeBox = new JComboBox<>(sizeStrings);
        //modeBox = new JComboBox<>(modeStrings);
        //levelBox = new JComboBox<>(levelStrings);
        

        subp.add(sizeBox);
        subp.add(Box.createVerticalStrut(40));
        //subp.add(modeBox);
        subp.add(Box.createVerticalStrut(40));
        //subp.add(levelBox);


        // sizeBox.addActionListener(e -> {
        //     if (sizeBox.getSelectedIndex() == 0){
        //         modeBox.setVisible(true);
        //     }
        //     else {
        //         modeBox.setVisible(false);
        //         levelBox.setVisible(false);
        //     }
            
        // });
        //
        // "modeBox.addActionListener(e -> {
        //     if (modeBox.getSelectedIndex() == 0 && modeBox.isVisible()){
        //         levelBox.setVisible(true);
        //     }
        //     else levelBox.setVisible(false);
        //     subp.revalidate();
        //     subp.repaint();
        // });

        // levelBox.addActionListener(e -> {
        //     String selected = (String) levelBox.getSelectedItem();
        //     switch (selected) {
        //     case "easy":
        //         System.out.println("Easy mode!");
        //         break;
        //     case "moderate":
        //         System.out.println("Medium mode!");
        //         break;
        //     case "hard":
        //         System.out.println("Hard mode!");
        //         break;
            
        //     }
        //     subp.revalidate();
        //     subp.repaint();
            
        // });"


        panel.add(subp);


        // Back button to return to menu
        JButton backButton = new JButton("Back");
        backButton.setBounds(25, 25, 100, 40);
        backButton.addActionListener(e -> {
            cardLayout.show(starterPanel, "Menu");
            System.out.println("Go back to the home page");
        });
        panel.add(backButton);
        //return
        return panel;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }
    
}