package Finalproject.code;

public class Main {
    public static void main(String[] args){
        StarterFrame start = new StarterFrame();
    }
}
